#Fuck Base, not Girls 

>pip install -r requirements.txt
>
>FAQ - https://teletype.in/@n4z4v0d/MAa4dmrO_Ij

Софт ебется с блокчейном BASE 

Список модулей: 

1) Способы пополнения: 

> Вывод с OKX

> Мост Orbiter - https://www.orbiter.finance/, доступные сети: Arbitrum, Optimism

2) Лендинги: 

> Aave - https://app.aave.com/?marketName=proto_base_v3

3) Свапы:

> Uniswap - https://app.uniswap.org/ 

> PancakeSwap - https://pancakeswap.finance/ 

> Woofi - https://fi.woo.org/swap/

> Odos - https://www.odos.xyz/ 

> Maverick - https://app.mav.xyz

> BaseSwap - https://baseswap.fi/ 

> 1Inch - https://app.1inch.io/

> Aerodrome - https://aerodrome.finance/swap

4) НФТ-Модули

> ZkStars - https://zkstars.io/ 

> MintFun - https://mint.fun/

5) Дополнительные приколы :)))

> Dmail - https://dmail.ai/

> Отправка ETH на свой адрес 

> Поддержка прокси

> Асинхронность

> Многопоток

> Уведомления в телеграм

> Полная рандомизация

О каждой настройке отдельно добавил пояснение в файле config.py
